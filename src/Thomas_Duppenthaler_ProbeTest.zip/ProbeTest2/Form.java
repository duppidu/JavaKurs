/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProbeTest2;

/**
 *
 * @author thomas.duppenthaler
 */
public abstract class Form
{
    int MINX = 0; // x-Koord. der linken oberen Ecke der Zeichenfläche
    int MINY = 0; // y- Koord. der linken oberen Ecke der Zeichenfläche
    int MAXX = 80; // x- Koord. der rechten unteren Ecke der Z.-Fläche
    int MAXY = 25; // y- Koord. der rechten unteren Ecke der Z.-Fläche 
    private int x;
    private int y;
    private static int objectCounter = 0;

    Form()
    {
        this.objectCounter++;
    }

    Form(int x, int y)
    {
        this.x = x;
        this.y = y;
        this.objectCounter++;
    }

    public void setX(int x)
    {
        this.x = x;
    }

    public void setY(int y)
    {
        this.y = y;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }

    public static int getObjectCounter()
    {
        return objectCounter;
    }

    
    @Override
    public String toString()
    {
        return "Form{" + "x=" + x + ", y=" + y + '}';
    }

    public abstract int getArea();

}
